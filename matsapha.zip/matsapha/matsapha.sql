-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2023 at 09:58 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matsapha`
--

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` int(20) NOT NULL,
  `CID` int(5) NOT NULL,
  `name` varchar(250) NOT NULL,
  `btype` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` int(20) NOT NULL,
  `website` varchar(255) NOT NULL,
  `year` int(4) NOT NULL,
  `useremail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`id`, `CID`, `name`, `btype`, `Description`, `address`, `phone`, `website`, `year`, `useremail`) VALUES
(2, 90456, 'Kusile construction', 'Construction', 'Construction for houses', 'opposite Netcom', 24045678, 'www.kusile.co.sz', 1998, 'langzo@gmail.com'),
(4, 8, 'Net Com', 'Information and Technology', 'We deliver I.T services ', 'opposite Kusile Construction', 24056721, 'www.netcom.co.sz', 1998, 'mnotfo@gmail.com'),
(5, 60000, 'Tiyandza Investment', 'Cooking', 'We offer cataring services around Eswatini', 'Sigodweni Matsapha', 20254312, 'tiyandza.com', 2017, 'mnofto@gmail.com'),
(8, 66666, 'Premeir', 'Bakery', 'Deliver bread, buns around Eswatini', 'PNPay Swaziland', 576886, 'www.premeir.co.sz', 2005, 'langzo@gmail.com'),
(9, 22222, 'Inyatsi Construction', 'Construction', 'We have excellency in construction of various structures in Eswatini, including bridges , Dams, and many more', 'Manzini', 1233333, 'www.inyatsi-group.com/eswatini', 1976, 'langzo@gmail.com'),
(11, 54533, 'Lusweti', 'Social', 'We do HIV', 'opposite Netcom', 24045678, 'dd.com', 1984, 'musa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `businessmesseges`
--

CREATE TABLE `businessmesseges` (
  `id` int(20) NOT NULL,
  `cid` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(20) NOT NULL,
  `messege` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `businessmesseges`
--

INSERT INTO `businessmesseges` (`id`, `cid`, `name`, `email`, `phone`, `messege`) VALUES
(1, 22222, 'Langazelwe Hlatshwako', 'langzo@gmail.com', 76223218, 'How much are the fees to construct a bridge'),
(2, 90456, 'Yenzoluhle', 'yenzo@gmail.com', 79345323, 'im yenzo just checking your system'),
(3, 22222, 'Musa', 'musa@gmail.com', 79345323, 'Hi');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(12) NOT NULL,
  `messege` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `email`, `phone`, `messege`) VALUES
(1, 'Langazelwe Hlatshwako', 'langzo@gmail.com', 76223218, 'hi'),
(3, 'Yenzoluhle', 'yenzo@gmail.com', 79345323, 'We love the system'),
(4, 'Mbali', 'mbali@gmail.com', 76192440, 'im just testing my seccess html page'),
(5, 'Mbali', 'mbali@gmail.com', 76192440, 'im just testing my seccess html page'),
(6, 'Bread', 'langa@gmail.com', 76223218, 'HGU');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'Langa', '902007899langazelwehlatjwayo@gmail.com', 'yenzo'),
(3, 'Okuhle ', 'okuhle@gmail.com', 'okuhle'),
(5, 'Mnotfo', 'mnotfo@gmail.com', 'yenzo'),
(6, 'Langa', 'langzo@gmail.com', 'yenzo'),
(7, 'Musa', 'musa@gmail.com', 'musa'),
(8, 'Tenele', 'tenele@gmail.com', 'tenele');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `businessmesseges`
--
ALTER TABLE `businessmesseges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `businessmesseges`
--
ALTER TABLE `businessmesseges`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
