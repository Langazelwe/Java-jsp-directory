
package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    
    
    
    
    private Connection DBConnection;

    
    public Connection connect(){
    
    try{
    
     Class.forName("com.mysql.jdbc.Driver");
     System.out.println("connection succesful");
    }
    
    catch(ClassNotFoundException cnfe){
    
    
     System.out.println("connection fail" + cnfe);
    
    }
    
        // String url; 
       // url = "jdbc:mysql://localhost:3306/rsp";
         
         try {
         
        DBConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/matsapha","root","");
        System.out.println("database connected");
         
         }
        catch(SQLException ss){
        
         System.out.println("No databases");
        
        }
         return DBConnection;
    
    }
}
   