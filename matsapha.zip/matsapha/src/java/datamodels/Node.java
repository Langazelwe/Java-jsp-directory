/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamodels;

/**
 *
 * @author  Mbali
 */
public class Node {
    Node leftChild;
    Node rightChild;
Businesses business;
public Node(){
}
public Node(Businesses business){
    this.business = business;
    leftChild = rightChild = null;
}
   
}
