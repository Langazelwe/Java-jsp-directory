/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamodels;

/**
 *
 * @author mbali
 */
public class BusinessTree {
    
    
     Node root;
     
    public BusinessTree() {
        this.root = null;
    }

    public void insertBusinesses(Businesses businesses) {

        Node newNode = new Node(businesses);

        if (root == null) {
            root = newNode;
            return; 

        }
        Node currentNode = root;

        Node parrentNode = null;

        while (true) {
            parrentNode = currentNode;
            if (businesses.getCompanyID()==(currentNode.business.getCompanyID())) {

                System.out.print("Business ID No: " + businesses.getCompanyID() + " " 
                        + "Already Registered, Try Again With A New One!!");
                return;
                
            } 
            else if (businesses.getCompanyID() <currentNode.business.getCompanyID()) {

                currentNode = currentNode.leftChild;
                if (currentNode == null) {
                    parrentNode.leftChild = newNode;
                    return;
                }

            } else {

                currentNode = currentNode.rightChild;
                if (currentNode == null) {
                    parrentNode.rightChild = newNode;
                    return;
               }
           }
        }
    }

    public void displayUsers(Node root1) {
        
        if (root1 != null) {
            displayUsers(root1.leftChild);
           
            System.out.println(root1.business.getCompanyID() + "\t " +root1.business.getName() + " \t" + root1.business.getField() + "\t " + root1.business.getAddress() + " \t"
                    + root1.business.getDescription() +"\t"+ root1.business.getEmail()+"\t"+root1.business.getPhone()+"\t"+root1.business.getWebsite()+"\t" +root1.business.getPhone());
            displayUsers(root1.rightChild);

        }

    }
    public void search(int id){
    Node current = root;
    //set current to not = to null
    while(current != null){
    if(current.business.getCompanyID() == id){
        
      System.out.println("Company ID No: "+" "+ current.business.getCompanyID());
      System.out.println("Company Name: "+" "+ current.business.getName());

    return;
    }
    else if(current.business.getCompanyID() > id){
    current = current.leftChild;
    }
    else{
    current = current.rightChild;
    }
        
    }
    
System.out.println("Search Company ID No:"+ id +" Match Not Found??");
System.out.println("--------------------------------------------");
    }
    public boolean delete(int id){
        boolean isDeleted = false;
        Node parrent = root;
        Node current = root;
        
        boolean isLeftChiled = false;
        while(current.business.getCompanyID() != id){
        parrent = current;
        if(current.business.getCompanyID() > id){
        
            isLeftChiled = true;
            
            current = current.leftChild;
        }
        else{
            isLeftChiled = false;
        current = current.rightChild;
        }
        if(current == null){
        System.out.println("Search Company ID No. "+" "+id+" "+" No Match Found??");
        }
        }
        //continue with the part
        if(current.leftChild == null && current.rightChild == null){
            if(current == root){
            
            root = null;
            }
            if(isLeftChiled == true){
            
            parrent.leftChild = null;
            }
            else{
            parrent.rightChild = null;
            }
        
        }
        //has one kid
        else if(current.rightChild == null){
        if(current == root){
        root = current.rightChild;
        
        }else if( isLeftChiled){
            parrent.leftChild = parrent.rightChild;
        
        }
       
        else{
        parrent.rightChild = current.rightChild;
        }
        
        }
         else if(current.leftChild != null && current.rightChild != null){
         
         Node sucessor = getSucessor(current);
         if(current == root){
         root = sucessor;
         }
         else if(isLeftChiled){
         
             parrent.leftChild = sucessor;
         }
         else{
         parrent.rightChild = sucessor;
         }
         sucessor.leftChild = current.leftChild;
         }
        System.out.println("User ID No: "+id + " "+" Has Been Deleted");
        
    return isDeleted;
    }
    public Node getSucessor(Node deletedNode){
    Node sucessor = null;
    Node sucessorParent = null;
    
    Node current = deletedNode.rightChild;
    while(current != null){
    
    sucessorParent = sucessor;
    sucessor = current;
    current = current.leftChild;
    }if( sucessor != deletedNode.rightChild){
    
        sucessorParent.leftChild = sucessor.rightChild;
        sucessor.rightChild = deletedNode.rightChild; 
//to delete the node to the right child
    }
    
    return sucessor;
    }
public void printInOder(Node node){
    if(node == null){
    return;
    }
    printInOder(node.leftChild);
     System.out.println(node.business.getCompanyID() + "\t " +node.business.getName() + " \t" + node.business.getField() + "\t " + node.business.getAddress() + " \t"
                    + node.business.getDescription() +"\t"+ node.business.getEmail()+"\t"+node.business.getPhone()+"\t"+node.business.getWebsite()+"\t" +node.business.getPhone());
    
    printInOder(node.rightChild);
    
} 
public void printPreOder(Node node){
     if(node == null){
    return;
     }
    System.out.println(node.business.getCompanyID() + "\t " +node.business.getName() + " \t" + node.business.getField() + "\t " + node.business.getAddress() + " \t"
                    + node.business.getDescription() +"\t"+ node.business.getEmail()+"\t"+node.business.getPhone()+"\t"+node.business.getWebsite()+"\t" +node.business.getPhone());
    
    
     printInOder(node.leftChild);
     printInOder(node.rightChild);
     
}  
public void printPostOder(Node node){
     if(node == null){
    return;
}
          printInOder(node.leftChild);
     printInOder(node.rightChild);
     
    System.out.println(node.business.getCompanyID() + "\t " +node.business.getName() + " \t" + node.business.getField() + "\t " + node.business.getAddress() + " \t"
                    + node.business.getDescription() +"\t"+ node.business.getEmail()+"\t"+node.business.getPhone()+"\t"+node.business.getWebsite()+"\t" +node.business.getPhone());
    
    
     
}
public void printInOder(){
   printInOder(root);
} 
public void printPreOder(){
     printPreOder(root);
}
public void printPostOder(){
 printPostOder(root);
}
}
