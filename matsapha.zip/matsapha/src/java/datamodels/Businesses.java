/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datamodels;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author mbali
 */
public class Businesses {
   
    PreparedStatement pst=null;
   ResultSet rs=null;
    
     private Integer compID; 
    private String name; 
    private String field; 
    private String address; 
    private String descript; 
     private String email; 
    private String website; 
    private String phone; 
    public Businesses() { 
    }  
    public int getCompanyID() { 
        return this.compID; 
    }
     public void setCompanyID(int CID) { 
        this.compID = CID; 
    }  
    public String getName() { 
        return this.name; 
    }  
    public void setName(String BN) { 
        this.name = BN; 
    }  
    public String getAddress() { 
        return this.address; 
    }  
    public void setAddress(String ad) { 
        this.address = ad; 
    }  
    public String getDescription() { 
        return this.descript; 
    }  
    public void setDescription(String ds) { 
        this.descript = ds; 
    }  
    public String getEmail() { 
        return this.email; 
    }  
    public void setEmail(String em) { 
        this.email = em; 
         }  
     
    public String getWebsite() { 
        return this.website; 
    }  
    public void setWebsite(String wb) { 
        this.website = wb; 
         }  
     
    public String getPhone() { 
        return this.phone; 
    }  
    public void setPhone(String p) { 
        this.phone = p; 
         }  
    public String getField() { 
        return this.field; 
    }  
    public void setField(String f) { 
        this.field = f; 
         }   
}
